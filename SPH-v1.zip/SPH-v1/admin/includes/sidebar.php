     <aside id="slide-out" class="side-nav white fixed">
                <div class="side-nav-wrapper">
                    <div class="sidebar-profile">
                        <div class="sidebar-profile-image">
                            <img src="../assets/images/profile-image.png" class="circle" alt="">
                        </div>
                        <div class="sidebar-profile-info">
                       
                                <p>Admin</p>

                         
                        </div>
                    </div>
            
                <ul class="sidebar-menu collapsible collapsible-accordion" data-collapsible="accordion">
                    <li class="no-padding"><a class="waves-effect waves-grey" href="dashboard.php"><i class="material-icons"></i>Dashboard</a></li>
					<li class="no-padding">
                        <a class="collapsible-header waves-effect waves-grey"><i class="material-icons"></i>Manage Order <i class="nav-drop-icon material-icons"></i></a>
                        <div class="collapsible-body">
                            <ul>
                                <li><a href="order.php">New Order</a></li>
                                <!--<li><a href="">Post Order</a></li>-->
                            </ul>
                        </div>
                    </li>
                    
					
                    <li class="no-padding">
                        <a class="collapsible-header waves-effect waves-grey"><i class="material-icons"></i>Manage Project<i class="nav-drop-icon material-icons"></i></a>
                        <div class="collapsible-body">
                            <ul>
                                <li><a href="addproject.php">Add New Project</a></li>
								<li><a href="#">Ongoing Project</a></li>
								<li><a href="#">Completed Project</a></li>
                                <li><a href="manageproject.php">Update Project</a></li>
                            </ul>
                        </div>
                    </li>
					
					<li class="no-padding">
                        <a class="collapsible-header waves-effect waves-grey"><i class="material-icons"></i>Vendor's Project<i class="nav-drop-icon material-icons"></i></a>
                        <div class="collapsible-body">
                            <ul>
                                <li><a href="uploadproject.php">All Vendor's Project </a></li>
                                <li><a href="pending-projecthistory.php">Pending Project </a></li>
                                <li><a href="approvedproject-history.php">Approved Project</a></li>
                                  <li><a href="notapproved-project.php">Not Approved Project</a></li>
       
                            </ul>
                        </div>
                    </li>
					
					
                    <li class="no-padding">
                        <a class="collapsible-header waves-effect waves-grey"><i class="material-icons"></i>Manage Vendor<i class="nav-drop-icon material-icons"></i></a>
                        <div class="collapsible-body">
                            <ul>
                                <li><a href="addemployee.php">Add Vendor</a></li>
                                <li><a href="manageemployee.php">Manage Vendor</a></li>
       
                            </ul>
                        </div>
                    </li>

					<li class="no-padding">
                        <a class="collapsible-header waves-effect waves-grey"><i class="material-icons"></i>Manage Customer<i class="nav-drop-icon material-icons"></i></a>
                        <div class="collapsible-body">
                            <ul>
                                <li><a href="hirewriter.php">Add Customer</a></li>
                                <li><a href="managecustomer.php">Manage Customer</a></li>
       
                            </ul>
                        </div>
                    </li>


					<li class="no-padding">
                        <a class="collapsible-header waves-effect waves-grey"><i class="material-icons"></i>Department<i class="nav-drop-icon material-icons"></i></a>
                        <div class="collapsible-body">
                            <ul>
                                <li><a href="adddepartment.php">Add Department</a></li>
                                <li><a href="managedepartments.php">Manage Department</a></li>
                            </ul>
                        </div>
                    </li>
					
					 

                        <li class="no-padding">
                                <a class="waves-effect waves-grey" href="logout.php"><i class="material-icons"></i>Sign Out</a>
                            </li>  
                 

                 
              
                </ul>
                   <div class="footer">
                    <p class="copyright"><a href="https://www.schoolprojecthub.com/">SchoolProjectHub </a>©</p>
                
                </div>
                </div>
            </aside>